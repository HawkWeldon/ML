# Project Red — SAY-backend-compatible pipeline

**Scope:** These files belong to `Batata-Vada/project_red`, not `SAY-backend`.
No SAY-backend source code changes are necessary for this pipeline.
Verified against SAY-backend's export **schema v2**, `say-practice-v1` six-feature contract,
`logistic-regression` JSON artifact schema v1, and existing center/width policy.

## Files

```text
project_red/
├── .gitignore
├── .env.example
├── pipeline/
│   ├── __init__.py
│   ├── fetch_say_events.py       # authenticated v2 export -> JSONL
│   └── build_training_dataset.py # verified outcomes -> CSV
├── training/
│   ├── __init__.py
│   ├── model_contract.py         # SAY-compatible artifact and center/width logic
│   ├── pretrain.py               # synthetic bootstrap only
│   ├── online_update.py          # verified real-data partial_fit (+ --rebuild)
│   ├── predict.py                # local center/width smoke test
│   └── test_model.py             # sklearn vs JSON inference parity
└── tests/
    ├── test_pipeline.py         # simulated v2 API and dataset tests
    └── test_training.py         # local simulated online-training tests
```

Generated `data/`, `artifacts/bootstrap_v1/`, and `artifacts/online_v1/`
directories are created by the scripts. These are **not replacements** for old experimental `Dump/` or `Dump2/` folders.

## Requirements

Python 3.13-compatible packages: `requests`, `numpy`, `scikit-learn`, `joblib`.
For NixOS, install them through your normal Nix configuration; don't install them into your system Python blindly.

## Commands (from `project_red` root)

```bash
python3 -m unittest discover -s tests -v
python3 training/pretrain.py
python3 training/test_model.py
python3 training/predict.py
```

To collect real SAY events **only after backend is running**:

```bash
# For local test deployments only; use HTTPS for remote backends.
export SAY_BACKEND_URL=http://127.0.0.1:5001
export SAY_PROJECT_RED_EXPORT_TOKEN='<same-secret-configured-for-backend-export>'
python3 pipeline/fetch_say_events.py
python3 pipeline/build_training_dataset.py
python3 training/online_update.py
```

The backend requires its own `PROJECT_RED_EXPORT_TOKEN` and
`PROJECT_RED_PSEUDONYM_KEY` environment configuration. Never commit secrets.
An empty valid export produces an empty JSONL and a header-only CSV;
`online_update.py` then leaves the synthetic model untouched.

### Corrected/removed historical examples

The updater stores a hash for each learned practice event and refuses to
silently relearn or overlook a correction/removal. After reviewing the
changed source records, run:

```bash
python3 training/online_update.py --rebuild
```

This **replays all current eligible real rows from the original synthetic
bootstrap** rather than applying corrections to an already updated model.
It does not invent missing real data.

### Model contract / deployment

`model.json` uses:

- `artifact_schema_version: 1`
- `model_type: logistic-regression`
- `feature_contract: say-practice-v1`
- the six backend-ordered features
- scaler means/scales, `coef`, `intercept`, probability thresholds and rating grid.

The included `training/predict.py` reproduces the backend's existing rating-grid
policy: center is the **rating closest to the 60% target probability within the
45–75% acceptable band**; width is `upper_bound - lower_bound`.

The JSON is backend-compatible **in format**, but isn't automatically deployed.
SAY-backend defaults to `PROJECT_RED_ENABLED=False`; enabling a validated model
and supplying a model file path is a deployment/configuration choice, not a code
change. A running backend caches model JSON by path, so restart it or use a
versioned artifact path when deploying a new version.

**Do not deploy the synthetic baseline or automatically updated models without
real-data temporal evaluation/calibration checks.** Synthetic Brier/AUC numbers
only measure the simulated outcome generator. Train/live feature compatibility
is aligned with the backend's `history_features` export.

### Privacy / Git

`.gitignore` prevents *new* real-data commits, but Git already tracks files in
older versions of Project Red. In your actual checkout run:

```bash
git rm --cached data/say_practice_events.jsonl data/training_rows.csv
```

Then commit the `.gitignore` change and tracked-file removals. `Dump/app.db`
is also already present in the GitHub repository; assess whether it holds
personal information, and if so review Git history before making the repo public.

### Trust boundary

Never load arbitrary `.joblib` files from untrusted sources: Python pickle-based
serialization may execute code. `model.json` is plain data and is the intended
interchange format with SAY-backend.

## Testing notes

The tests generate temporary **simulated** events for contract checks, never
place synthetic records in production `data/say_practice_events.jsonl`, and
never need a live backend. The true live integration still needs a properly
configured backend and actual eligible Codeforces practice sessions.
